Welcome to EzegBasic vers. 1.1.01.7-6bXD!

This mini-sub-like coding lanquage was programmed by EternalGoat (Conner Cox) in the last week of his Senior High School year, or 5/22-30/17.

Ezeg Basic allows for simple and easy programing capabilities to make functions you could program much easier on a superior platform like TI-Basic (Totally not copied from TI-Basic, that is way to difficult to replicate).

Open the ExegBasicApp to use the program, and make sure to place your custom programs in the same folder and the compiler, otherwise you have to use the custom programs full pathname when calling it in the application. 

Quick Guide!
~~~~~~~~~~~~~
1. Operators allow for additional instructions. 
	Ex. {print} {=} {get} and so on. List of operators and ther functions listed in "OperatorList.txt".

2. Every statement must end on its own line. 
	Ex. a + b = c
		b + c = d
	
3. There can only be one operator in a statement.
	Ex. {+} a + b + c = d <------ This statement is WRONG!
	
4. There can only be 10 variables in a program, running a-j. This is as of verison EzegBasic_1.1.01.7-6bXD.

5. Only variables can be used for operations. This means to times a variable by a number, that number must be assigned to another variable. 
    Ex. {=} a = 6
        {=} b = 5
        a + b = c
		{comm} c = 11
		{comm} a + 5 will NOT work.
		
6. Clarification Hint: Operators are the sections enclosed in {}. These inform the compiler to do something special. Operations are normal math operations, + - / * ect. 